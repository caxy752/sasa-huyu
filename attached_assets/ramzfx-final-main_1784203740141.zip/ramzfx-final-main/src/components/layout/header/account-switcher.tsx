import { MouseEvent as ReactMouseEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import classNames from 'classnames';
import { observer } from 'mobx-react-lite';
import { CurrencyIcon } from '@/components/currency/currency-icon';
import { addComma, getDecimalPlaces } from '@/components/shared';
import Text from '@/components/shared_ui/text';
import { api_base } from '@/external/bot-skeleton/services/api/api-base';
import { useApiBase } from '@/hooks/useApiBase';
import { useStore } from '@/hooks/useStore';
import { isDemoAccount } from '@/utils/account-helpers';
import { CURRENCY_FLAGS, DISPLAY_CURRENCIES, formatDisplayBalanceValue, getCurrencyFlag, resolveDisplayCurrency, TDisplayCurrency } from '@/utils/display-currency';
import { Localize } from '@deriv-com/translations';
import { TAccountSwitcher } from './common/types';
import AccountInfoWrapper from './account-info-wrapper';
import './account-switcher.scss';

const CURRENCY_NAMES: Record<string, string> = {
    AUD: 'Australian Dollar',
    BTC: 'Bitcoin',
    ETH: 'Ether',
    EUR: 'Euro',
    GBP: 'Pound Sterling',
    LTC: 'Litecoin',
    USD: 'US Dollar',
    USDC: 'USD Coin',
    UST: 'Tether Omni',
    EUSDT: 'Tether ERC20',
    TUSDT: 'Tether TRC20',
};

const getCurrencyName = (currency?: string) => CURRENCY_NAMES[currency?.toUpperCase() ?? ''] ?? currency ?? 'Account';
const DOLLAR_ICON_DEMO_LOGINID = 'DOT91317422';

const AccountSwitcher = observer(({ activeAccount }: TAccountSwitcher) => {
    const [isOpen, setIsOpen] = useState(false);
    const [isCurrencyMenuOpen, setIsCurrencyMenuOpen] = useState(false);
    const [activeDropdownTab, setActiveDropdownTab] = useState<'real' | 'demo'>('real');
    const wrapperRef = useRef<HTMLDivElement>(null);
    const { accountList, activeLoginid } = useApiBase();
    const { client, run_panel } = useStore() ?? {};

    const [resetMessage, setResetMessage] = useState<string>('');
    const [resetError, setResetError] = useState<string>('');
    const [isResetting, setIsResetting] = useState<boolean>(false);

    const is_bot_running = run_panel?.is_running || api_base.is_running;
    const isSingleAccount = !accountList || accountList.length <= 1;

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
                setIsOpen(false);
                setIsCurrencyMenuOpen(false);
            }
        };
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                setIsOpen(false);
                setIsCurrencyMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, []);

    useEffect(() => {
        if (!activeAccount) return;

        setActiveDropdownTab(activeAccount.isVirtual ? 'demo' : 'real');
    }, [activeAccount?.isVirtual, activeAccount?.loginid]);

    const toggleDropdown = useCallback(() => {
        if (is_bot_running || isSingleAccount) return;
        setIsCurrencyMenuOpen(false);
        setIsOpen(prev => !prev);
    }, [is_bot_running, isSingleAccount]);

    const toggleCurrencyMenu = useCallback(
        (event: ReactMouseEvent<HTMLButtonElement>) => {
            event.stopPropagation();
            setIsOpen(false);
            setIsCurrencyMenuOpen(prev => !prev);
        },
        []
    );

    const handleDisplayCurrencySelect = useCallback(
        (currency_code: TDisplayCurrency) => {
            client?.setDisplayCurrency(resolveDisplayCurrency(currency_code));
            setIsCurrencyMenuOpen(false);
        },
        [client]
    );

    const handleAccountSelect = useCallback(
        (loginid: string) => {
            localStorage.setItem('active_loginid', loginid);
            localStorage.setItem('account_type', isDemoAccount(loginid) ? 'demo' : 'real');

            const accountsListRaw = localStorage.getItem('accountsList');
            if (accountsListRaw) {
                try {
                    const accountsList = JSON.parse(accountsListRaw) as Record<string, string>;
                    if (accountsList[loginid]) localStorage.setItem('authToken', accountsList[loginid]);
                } catch (error) {
                    console.error('[AccountSwitcher] Failed to update legacy auth token:', error);
                }
            }

            client?.checkAndRegenerateWebSocket();
            setIsOpen(false);
        },
        [client]
    );

    const formattedAccounts = useMemo(() => {
        if (!accountList) return [];
        return accountList
            .map(account => ({
                loginid: account.loginid,
                currency: account.currency,
                balance: addComma(Number(account.balance ?? 0).toFixed(getDecimalPlaces(account.currency))),
                isVirtual: isDemoAccount(account.loginid),
                isActive: account.loginid === activeLoginid,
            }))
            .sort((a, b) => (a.isActive ? -1 : b.isActive ? 1 : 0));
    }, [accountList, activeLoginid]);

    const currency = activeAccount?.currency;
    const isVirtual = activeAccount?.isVirtual ?? false;
    const balance = activeAccount?.balance;
    const loginid = activeAccount?.loginid;
    const showChevron = !isSingleAccount && !is_bot_running;
    const realAccounts = formattedAccounts.filter(account => !account.isVirtual);
    const demoAccounts = formattedAccounts.filter(account => account.isVirtual);
    const selectedDisplayCurrency = resolveDisplayCurrency(client?.display_currency, 'USD');
    const shouldShowDollarIconForActiveDemo = loginid === DOLLAR_ICON_DEMO_LOGINID;
    const headerBalance = formatDisplayBalanceValue(
        balance ?? 0,
        currency || 'USD',
        selectedDisplayCurrency,
        client?.usd_rates
    );

    const handleTabSelect = useCallback((tab: 'real' | 'demo') => {
        setActiveDropdownTab(tab);
    }, []);

    const handleResetSubmit = useCallback(
        (e: React.FormEvent) => {
            e.preventDefault();
            setResetMessage('');
            setResetError('');

            const currentActiveLogin = activeLoginid || loginid || '';

            // Only allow reset when a demo account is active
            if (!isDemoAccount(currentActiveLogin)) {
                setResetError('Switch to a demo account to reset its balance.');
                return;
            }

            const accountCurrency =
                demoAccounts.find(a => a.loginid === currentActiveLogin)?.currency || client?.getAccountCurrency?.(currentActiveLogin) || 'USD';

            setIsResetting(true);
            client
                ?.resetDemoBalance?.(currentActiveLogin, undefined, accountCurrency)
                .then(result => {
                    if (result?.success) {
                        setResetMessage(
                            typeof result.amount === 'number'
                                ? `Demo balance reset to ${result.amount.toFixed(2)} ${accountCurrency}`
                                : 'Demo balance reset requested. Your balance will update in a moment.'
                        );
                    } else {
                        setResetError(
                            result?.error ||
                                'Deriv could not top up this account. Your balance may already be at or above the starting amount.'
                        );
                    }
                })
                .catch(err => {
                    console.error('Demo reset failed', err);
                    setResetError('Failed to reset demo balance.');
                })
                .finally(() => setIsResetting(false));
        },
        [activeLoginid, loginid, client, demoAccounts]
    );

    if (!activeAccount) return null;

    return (
        <div className='acc-info__wrapper' ref={wrapperRef}>
            <AccountInfoWrapper>
                <div className='acc-info__currency-switcher'>
                    <button
                        className='acc-info__currency-button'
                        type='button'
                        onClick={toggleCurrencyMenu}
                        aria-expanded={isCurrencyMenuOpen}
                        aria-haspopup='listbox'
                    >
                        <span className='acc-info__currency-flag' aria-hidden='true'>
                            {CURRENCY_FLAGS[selectedDisplayCurrency]}
                        </span>
                        {selectedDisplayCurrency}
                        <svg width='10' height='10' viewBox='0 0 10 10' fill='none' aria-hidden='true'>
                            <path d='M2 3.5L5 6.5L8 3.5' stroke='currentColor' strokeWidth='1.5' strokeLinecap='round' />
                        </svg>
                    </button>
                    {isCurrencyMenuOpen && (
                        <div className='acc-info__currency-menu' role='listbox'>
                            {DISPLAY_CURRENCIES.map(option => (
                                <button
                                    key={option}
                                    type='button'
                                    className={classNames('acc-info__currency-option', {
                                        'acc-info__currency-option--active': option === selectedDisplayCurrency,
                                    })}
                                    onClick={() => handleDisplayCurrencySelect(option)}
                                >
                                    <span className='acc-info__currency-flag' aria-hidden='true'>
                                        {CURRENCY_FLAGS[option]}
                                    </span>
                                    {option}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
                <div
                    data-testid='dt_acc_info'
                    id='dt_core_account-info_acc-info'
                    role={showChevron ? 'button' : undefined}
                    tabIndex={showChevron ? 0 : -1}
                    aria-expanded={showChevron ? isOpen : undefined}
                    aria-haspopup={showChevron ? 'listbox' : undefined}
                    className={classNames('acc-info', {
                        'acc-info--is-virtual': isVirtual,
                        'acc-info--interactive': showChevron,
                    })}
                    onClick={toggleDropdown}
                    onKeyDown={e => {
                        if (showChevron && (e.key === 'Enter' || e.key === ' ')) {
                            e.preventDefault();
                            toggleDropdown();
                        }
                    }}
                >
                    <span className='acc-info__id' aria-hidden='true'>
                        <CurrencyIcon
                            currency={currency?.toLowerCase()}
                            isVirtual={isVirtual && !shouldShowDollarIconForActiveDemo}
                        />
                    </span>
                    <div className='acc-info__content'>
                        {(typeof balance !== 'undefined' || !currency) && (
                            <div className='acc-info__balance-section'>
                                <p
                                    data-testid='dt_balance'
                                    className={classNames('acc-info__balance', {
                                        'acc-info__balance--no-currency': !currency && !isVirtual,
                                    })}
                                >
                                    {!currency ? (
                                        <Localize i18n_default_text='No currency assigned' />
                                    ) : (
                                        <>
                                            {!isVirtual && selectedDisplayCurrency !== 'USD' && (
                                                <span className='acc-info__balance-flag' aria-hidden='true'>
                                                    {getCurrencyFlag(selectedDisplayCurrency)}
                                                </span>
                                            )}
                                            {headerBalance}
                                        </>
                                    )}
                                </p>
                            </div>
                        )}
                    </div>
                    {showChevron && (
                        <span
                            className={classNames('acc-info__select-arrow', {
                                'acc-info__select-arrow--invert': isOpen,
                            })}
                        >
                            <svg width='14' height='14' viewBox='0 0 14 14' fill='none'>
                                <path
                                    d='M3 5L7 9L11 5'
                                    stroke='currentColor'
                                    strokeWidth='1.8'
                                    strokeLinecap='round'
                                    strokeLinejoin='round'
                                />
                            </svg>
                        </span>
                    )}
                </div>
            </AccountInfoWrapper>
            {isOpen && (
                <div className='acc-dropdown' role='listbox'>
                    <div className='acc-dropdown__tabs' role='tablist'>
                        <button
                            type='button'
                            role='tab'
                            aria-selected={activeDropdownTab === 'real'}
                            className={classNames('acc-dropdown__tab', {
                                'acc-dropdown__tab--active': activeDropdownTab === 'real',
                            })}
                            onClick={() => handleTabSelect('real')}
                        >
                            Real
                        </button>
                        <button
                            type='button'
                            role='tab'
                            aria-selected={activeDropdownTab === 'demo'}
                            className={classNames('acc-dropdown__tab', {
                                'acc-dropdown__tab--active': activeDropdownTab === 'demo',
                            })}
                            onClick={() => handleTabSelect('demo')}
                        >
                            Demo
                        </button>
                    </div>
                    {activeDropdownTab === 'real' && realAccounts.length > 0 && (
                        <div className='acc-dropdown__group'>
                            <div className='acc-dropdown__group-title'>
                                <span>Deriv accounts</span>
                                <span className='acc-dropdown__group-chevron' aria-hidden='true'>
                                    ^
                                </span>
                            </div>
                            {realAccounts.map(account => (
                                <div
                                    key={account.loginid}
                                    role='option'
                                    aria-selected={account.isActive}
                                    tabIndex={0}
                                    className={classNames('acc-dropdown__account', {
                                        'acc-dropdown__account--selected': account.isActive,
                                    })}
                                    onClick={() => !account.isActive && handleAccountSelect(account.loginid)}
                                    onKeyDown={e => {
                                        if (!account.isActive && (e.key === 'Enter' || e.key === ' ')) {
                                            e.preventDefault();
                                            handleAccountSelect(account.loginid);
                                        }
                                    }}
                                >
                                    <span className='acc-dropdown__account-icon'>
                                        <CurrencyIcon currency={account.currency?.toLowerCase()} />
                                    </span>
                                    <span className='acc-dropdown__account-info'>
                                        <Text as='span' size='xs' weight='bold' className='acc-dropdown__currency'>
                                            {getCurrencyName(account.currency)}
                                        </Text>
                                        <Text as='span' size='xxxs' className='acc-dropdown__loginid'>
                                            {account.loginid}
                                        </Text>
                                    </span>
                                    <Text as='span' size='xs' weight='bold' className='acc-dropdown__balance'>
                                        {account.currency ? (
                                            <>
                                                {selectedDisplayCurrency !== 'USD' && (
                                                    <span className='acc-dropdown__balance-flag' aria-hidden='true'>
                                                        {getCurrencyFlag(selectedDisplayCurrency)}
                                                    </span>
                                                )}
                                                {formatDisplayBalanceValue(
                                                    account.balance,
                                                    account.currency,
                                                    selectedDisplayCurrency,
                                                    client?.usd_rates
                                                )}
                                            </>
                                        ) : (
                                            <Localize i18n_default_text='No currency assigned' />
                                        )}
                                    </Text>
                                </div>
                            ))}
                        </div>
                    )}
                    {activeDropdownTab === 'demo' && demoAccounts.length > 0 && (
                        <div className='acc-dropdown__group'>
                            <div className='acc-dropdown__group-title'>
                                <span>Demo accounts</span>
                                <span className='acc-dropdown__group-chevron' aria-hidden='true'>
                                    ^
                                </span>
                            </div>
                            {demoAccounts.map(account => {
                                const shouldShowDollarIcon = account.loginid === DOLLAR_ICON_DEMO_LOGINID;

                                return (
                                    <div
                                        key={account.loginid}
                                        role='option'
                                        aria-selected={account.isActive}
                                        tabIndex={0}
                                        className={classNames('acc-dropdown__account', {
                                            'acc-dropdown__account--selected': account.isActive,
                                        })}
                                        onClick={() => !account.isActive && handleAccountSelect(account.loginid)}
                                        onKeyDown={e => {
                                            if (!account.isActive && (e.key === 'Enter' || e.key === ' ')) {
                                                e.preventDefault();
                                                handleAccountSelect(account.loginid);
                                            }
                                        }}
                                    >
                                        <span className='acc-dropdown__account-icon'>
                                            <CurrencyIcon
                                                currency={account.currency?.toLowerCase()}
                                                isVirtual={!shouldShowDollarIcon}
                                            />
                                        </span>
                                        <span className='acc-dropdown__account-info'>
                                            <Text as='span' size='xs' weight='bold' className='acc-dropdown__currency'>
                                                Demo
                                            </Text>
                                            <Text as='span' size='xxxs' className='acc-dropdown__loginid'>
                                                {account.loginid}
                                            </Text>
                                        </span>
                                        <Text as='span' size='xs' weight='bold' className='acc-dropdown__balance'>
                                            {formatDisplayBalanceValue(
                                                account.balance,
                                                account.currency,
                                                selectedDisplayCurrency,
                                                client?.usd_rates
                                            )}
                                        </Text>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                    {activeDropdownTab === 'real' && realAccounts.length === 0 && (
                        <div className='acc-dropdown__empty'>No real accounts available.</div>
                    )}
                    {activeDropdownTab === 'demo' && demoAccounts.length === 0 && (
                        <div className='acc-dropdown__empty'>No demo accounts available.</div>
                    )}

                    {/* Demo reset section */}
                    {activeDropdownTab === 'demo' && (
                        <div className='acc-dropdown__reset'>
                            <div className='acc-dropdown__reset-title'>Reset demo balance</div>
                            <p className='acc-dropdown__reset-copy'>
                                Tops up your active demo account with Deriv, back to its starting balance. Deriv only
                                allows this when your balance has dropped below the starting amount — you can&apos;t
                                set a custom amount.
                            </p>

                            <form onSubmit={handleResetSubmit}>
                                <button type='submit' className='acc-dropdown__reset-button' disabled={isResetting}>
                                    {isResetting ? 'Resetting…' : 'Reset Demo Account Balance'}
                                </button>
                            </form>

                            {resetError && <p className='acc-dropdown__reset-error'>{resetError}</p>}
                            {resetMessage && <p className='acc-dropdown__reset-success'>{resetMessage}</p>}
                        </div>
                    )}

                    <div className='acc-dropdown__traders-hub'>Looking for CFD accounts? Go to Trader&apos;s Hub</div>
                    <div className='acc-dropdown__footer'>
                        <button className='acc-dropdown__manage' type='button'>
                            Manage accounts
                        </button>
                        <button className='acc-dropdown__logout' type='button' onClick={() => client?.logout()}>
                            Logout
                            <svg width='16' height='16' viewBox='0 0 16 16' fill='none' aria-hidden='true'>
                                <path
                                    d='M6 3H3.5A1.5 1.5 0 0 0 2 4.5v7A1.5 1.5 0 0 0 3.5 13H6M10 5l3 3-3 3M13 8H5'
                                    stroke='currentColor'
                                    strokeWidth='1.4'
                                    strokeLinecap='round'
                                    strokeLinejoin='round'
                                />
                            </svg>
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
});

export default AccountSwitcher;
